package com.cg.ikea.dao;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.ikea.beans.GiftCards;
import com.cg.ikea.exception.CardNumberNotExistException;

public class GiftCardsDao implements IGiftCardsDao {

	private EntityManagerFactory factory;

	public GiftCardsDao() {
		factory = Persistence.createEntityManagerFactory("GiftCards-Service");
	}

	public boolean updateVerificationCode(StringBuffer issuer, int cardTypeDigit, StringBuffer accountNumber,
			int checkDigit, String verificationCode) throws CardNumberNotExistException {

		EntityManager manager = factory.createEntityManager();

		Query query = manager.createQuery(
				"select c from GiftCards c where c.issuer = " + issuer + " and c.cardTypeDigit = " + cardTypeDigit
						+ " and c.accountNumber = " + accountNumber + " and c.checkDigit = " + checkDigit);

		@SuppressWarnings("unchecked")
		List<GiftCards> list = query.getResultList();
		if (!list.isEmpty()) {

			long cardNumberId = list.get(0).getCardNumberId();

			String defaultVerificationCode = list.get(0).getVerificationCode();

			if (defaultVerificationCode == null) {
				GiftCards findCard = manager.find(GiftCards.class, cardNumberId);
				manager.getTransaction().begin();
				System.out.println(findCard.toString());
				findCard.setVerificationCode(verificationCode);
				findCard.setUpdatedBy("EBCCARDPAY1");
				Date date = new Date();
				findCard.setUpdatedDateTime(date);
				manager.getTransaction().commit();
				return true;
			}
		} else {
			throw new CardNumberNotExistException("Card Number does not exist");
		}

		return false;
	}

}