package com.cg.ikea.dao;

import com.cg.ikea.exception.CardNumberNotExistException;

public interface IGiftCardsDao {

	public boolean updateVerificationCode(StringBuffer issuer, int cardTypeDigit, StringBuffer accountNumber,
			int checkDigit, String verificationCode) throws CardNumberNotExistException;
}
