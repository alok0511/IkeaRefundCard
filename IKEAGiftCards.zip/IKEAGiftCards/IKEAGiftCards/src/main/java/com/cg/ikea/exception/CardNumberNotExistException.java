package com.cg.ikea.exception;

public class CardNumberNotExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CardNumberNotExistException(String msg) {
		super(msg);
	}

}
