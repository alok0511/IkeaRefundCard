package com.cg.ikea.exception;

public class OnlyRefundCardException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OnlyRefundCardException(String msg) {
		super(msg);
	}

}
