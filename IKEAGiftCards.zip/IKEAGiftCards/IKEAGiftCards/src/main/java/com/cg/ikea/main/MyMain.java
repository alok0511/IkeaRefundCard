package com.cg.ikea.main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

import com.cg.ikea.dao.GiftCardsDao;
import com.cg.ikea.dao.IGiftCardsDao;
import com.cg.ikea.service.GiftCardsService;
import com.cg.ikea.service.IGiftCardsService;

public class MyMain {

	private static IGiftCardsDao giftCardsDao = new GiftCardsDao();
	private static IGiftCardsService giftCardsService = new GiftCardsService(giftCardsDao);

	public static void main(String[] args) {

		BufferedReader reader;

		BufferedWriter writer;
		

		try {

			reader = new BufferedReader(new FileReader("C:\\Users\\shash\\Downloads\\SELP_load.txt"));
			String line = reader.readLine();

			while (line != null) {
				String cardNumber = null;
				String verificationCode = null;
				try {
					String str[] = line.split(";");
					cardNumber = str[0];
					verificationCode = str[1];
				} catch (Exception e) {
					System.err.println(e.getMessage());
				}

				StringBuffer issuer = new StringBuffer(cardNumber.substring(0, 6));
				StringBuffer cardTypeDigitString = new StringBuffer(cardNumber.substring(6, 7));
				StringBuffer accountNumber = new StringBuffer(cardNumber.substring(7, 18));
				StringBuffer digitCheckString = new StringBuffer(cardNumber.substring(18, 19));

				int cardTypeDigit = Integer.parseInt(cardTypeDigitString.toString());
				int checkDigit = Integer.parseInt(digitCheckString.toString());

				System.out.println(issuer + " " + cardTypeDigit + " " + accountNumber + " " + checkDigit);
				boolean check=false;
				try {
					check = giftCardsService.updateVerificationCode(cardNumber, verificationCode);
				}
				catch(Exception e) {
					System.err.println(e.getMessage());
				}
				
				if (check == true) {
					System.out.println("Verification Code updated successfully");
				} else {
					System.out.println("Verification Code already updated");
					writer = new BufferedWriter(new FileWriter("C:\\Users\\shash\\Downloads\\ABD.txt", true));
					writer.write(cardNumber + ";" + verificationCode + ";");
					writer.newLine();
					writer.close();
				}
				line = reader.readLine();
			}

		} catch (Exception e) {
			System.err.println(e.getMessage());

		}

	}
}