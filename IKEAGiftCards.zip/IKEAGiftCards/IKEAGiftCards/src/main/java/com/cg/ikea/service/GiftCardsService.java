package com.cg.ikea.service;

import com.cg.ikea.dao.IGiftCardsDao;
import com.cg.ikea.exception.CardNumberNotExistException;
import com.cg.ikea.exception.InvalidInputException;
import com.cg.ikea.exception.OnlyRefundCardException;

public class GiftCardsService implements IGiftCardsService {

	private IGiftCardsDao giftCardsDao;

	public GiftCardsService(IGiftCardsDao giftCardsDao) {
		super();
		this.giftCardsDao = giftCardsDao;
	}

	public boolean updateVerificationCode(String cardNumber, String verificationCode)
			throws InvalidInputException, OnlyRefundCardException, CardNumberNotExistException {

		// String issuer = cardNumber.substring(0, 6);
		// String cardTypeDigitString = cardNumber.substring(6, 7);
		// String accountNumber = cardNumber.substring(7, 18);
		// String digitCheckString = cardNumber.substring(18, 19);

		StringBuffer issuer = new StringBuffer(cardNumber.substring(0, 6));
		StringBuffer cardTypeDigitString = new StringBuffer(cardNumber.substring(6, 7));
		StringBuffer accountNumber = new StringBuffer(cardNumber.substring(7, 18));
		StringBuffer digitCheckString = new StringBuffer(cardNumber.substring(18, 19));

		int cardTypeDigit = Integer.parseInt(cardTypeDigitString.toString());
		int checkDigit = Integer.parseInt(digitCheckString.toString());

		if (cardTypeDigit != 4) {
			throw new OnlyRefundCardException("Card Type Digit should be 4");
		}
		if (verificationCode == null || verificationCode.length() != 4) {
			throw new InvalidInputException("Verification Code is not valid,it must be of 4 digit only");
		}

		return giftCardsDao.updateVerificationCode(issuer, cardTypeDigit, accountNumber, checkDigit, verificationCode);
	}

}
