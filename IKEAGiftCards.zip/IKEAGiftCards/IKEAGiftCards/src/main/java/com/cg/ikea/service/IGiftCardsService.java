package com.cg.ikea.service;

import com.cg.ikea.exception.CardNumberNotExistException;
import com.cg.ikea.exception.InvalidInputException;
import com.cg.ikea.exception.OnlyRefundCardException;

public interface IGiftCardsService {

	public boolean updateVerificationCode(String cardNumber, String verificationCode)
			throws OnlyRefundCardException, InvalidInputException, CardNumberNotExistException;

}
